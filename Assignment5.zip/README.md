@Author -- Jakob Horvath

The included source code files can all be compiled and ran in Matlab
when the PowerMethod.m and PowerMethodInv.m functions are available 
for reference.

The source code files break down as follows:

1. assign5_1.m

2. assign5_2.m (requires: PowerMethod.m, PowerMethodInv.m)
