function [y] = func3_3(x)
%FUNC3_3 Function used for script file assign3_3.m
y = exp(x);
end

