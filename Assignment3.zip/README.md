@Author -- Jakob Horvath

The included source code files can all be compiled and run in Matlab
when the func3_3.m and pvand.m functions are available for reference
(dvand.m is never used).

The source code files break down as follows:

1. assign3_1.m

2. assign3_2.m

3. assign3_3.m (requires: func3_3.m, pvand.m)