@Author -- Jakob Horvath

The included source code files can all be compiled and ran in Matlab
when the data.txt file is avaiable for reference.

The source code files break down as follows:

1. assign6_1.m (requires: data.txt)

2. assign6_2.m
